package project;

public class Driver {
	
	public static void main (String[] args) {
		Connector chat = new Connector();
		do {
			Connector.messageHolder();
		} while(true);
	}
}