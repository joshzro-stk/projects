package project;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.DatagramPacket;
import java.util.HashMap;


import javax.swing.*;

public class Connector extends JFrame{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel panel,panel2;
	private JTextField port,ip;
	private static HashMap<String, ChatWindow> trackerMap = new HashMap<String,ChatWindow>();
	private JButton chat;
	private static Socket joshSocket;

	public Connector() {
		
		joshSocket = new Socket(64000, Socket.SocketType.NoBroadcast);
		
		setTitle("Enter Destination Port and IP Address");
		setSize(500, 175);
		
		 panel = new JPanel();
		 panel2 = new JPanel();

		 chat = new JButton("Chat");
		
		JLabel ipText = new JLabel("IP Address:");
		JLabel portNumber = new JLabel("Port:");		

		port = new JTextField(8);
		ip = new JTextField(18);

		panel.add(ipText);
		panel.add(ip);
		
		panel2.add(portNumber);
		panel2.add(port);
	
		
		chat.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String ipa = ip.getText();
				String portString = port.getText();
				String key = ipa + " " + portString;
				
				if (!ipa.isEmpty() && !portString.isEmpty() && !trackerMap.containsKey(key)) {
					ChatWindow window = new ChatWindow(joshSocket, Integer.parseInt(portString), ipa);
					
					trackerMap.put(key, window);
					
					ip.setText("");
					port.setText("");
				}
				
			}
			
		});
		getRootPane().setDefaultButton(chat);
		add(BorderLayout.PAGE_START, panel);
		add(BorderLayout.CENTER, panel2);
		add(BorderLayout.SOUTH, chat);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true); 
	}
	public static void messageHolder() {
		DatagramPacket inPacket = null;
		
		do {
			
			try {
				inPacket = joshSocket.receive();
				if (inPacket != null) {
				
					String msg = new String(inPacket.getData());
					String ip = inPacket.getAddress().getHostAddress();
					int port = inPacket.getPort();
					String key = ip + " " + port;
					ChatWindow window = null;
					
					if (trackerMap.containsKey(key)) {
						window = trackerMap.get(key);
						window.getHistory().append("Buddy: " + msg + "\n");
						window.setVisible(true);
					} 
					else {
						window = new ChatWindow(joshSocket, port, ip);
						trackerMap.put(key, window);
						window.getHistory().append("Buddy: " + msg + "\n");
						window.setVisible(true);
					}
				}
			} catch (NullPointerException npe) {
			}
		} while (true);
	}

		
	}



