package project;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.InetAddress;
import java.net.UnknownHostException;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ChatWindow extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField msg;
	private JTextArea history = new JTextArea();
	private InetAddress address;
	private int port;
	JPanel panel;
	JButton send;
	public final InetAddress getAddress() {
		return address;
	}


	public final void setAddress(InetAddress address) {
		this.address = address;
	}

	
	public final void setHistory(JTextArea history) {
		this.history = history;
	}

	
	public final JTextField getMsg() {
		return msg;
	}
	public final JTextArea getHistory() {
		return history;
	}

	
	public ChatWindow(Socket socket, int port ,String ip)  {
		this.setPort(port);
		
		try {
			this.address = InetAddress.getByName(ip);
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
			System.exit(-1);
		}
		
		setTitle("IP Address: " + ip  + "    " + "Port: " + port);
		
		setLocationRelativeTo(null);

		setSize(500, 500);

		panel = new JPanel();

		history.setEditable(false);
		send = new JButton("Send");
		
		msg = new JTextField(30);

		panel.add(msg);
		panel.add(send);
		panel.setVisible(true);	
		
		
		
		getContentPane().add(BorderLayout.SOUTH, panel);

		getContentPane().add(BorderLayout.CENTER, history);



		
	
		send.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String msg = getMsg().getText();
				
				if (!msg.isEmpty()) {
					history.append("me: " + msg + "\n");
					getMsg().setText("");
					socket.send(msg, getAddress(), getPort());
				}
				
			}


		
			
		});
		getRootPane().setDefaultButton(send);
		setVisible(true);

	}


	public int getPort() {
		return port;
	}


	public void setPort(int port) {
		this.port = port;
	}
}

	